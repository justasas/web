� About :
http://www.imdb.com/title/tt0052561/
Anatomy of a Murder (1959)
*
1 file - 1/4 DVD or 1120Mb.
-
DVDripped to AVI - NO Qpel, Standalone support enabled: ESS.
  23.976 fps,  512*384 (4:3),  XVID = XVID Mpeg-4,Audio CBR,MP3.
[as reported by http://avicodec.duby.info/ ]